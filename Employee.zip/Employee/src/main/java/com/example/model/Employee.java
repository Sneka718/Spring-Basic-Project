package com.example.model;

	import jakarta.validation.constraints.Min;
	import jakarta.validation.constraints.NotBlank;

	public class Employee {

	    private int employeeId;

	    @NotBlank(message = "Employee name is required")
	    private String employeeName;

	    @NotBlank(message = "Leave type is mandatory")
	    private String leaveType;

	    @Min(value = 1, message = "Leave days should be minimum 1")
	    private int numberOfDays;

	    private String reason;

	    public int getEmployeeId() {
	        return employeeId;
	    }

	    public void setEmployeeId(int employeeId) {
	        this.employeeId = employeeId;
	    }

	    public String getEmployeeName() {
	        return employeeName;
	    }

	    public void setEmployeeName(String employeeName) {
	        this.employeeName = employeeName;
	    }

	    public String getLeaveType() {
	        return leaveType;
	    }

	    public void setLeaveType(String leaveType) {
	        this.leaveType = leaveType;
	    }

	    public int getNumberOfDays() {
	        return numberOfDays;
	    }

	    public void setNumberOfDays(int numberOfDays) {
	        this.numberOfDays = numberOfDays;
	    }

	    public String getReason() {
	        return reason;
	    }

	    public void setReason(String reason) {
	        this.reason = reason;
	    }
	}
