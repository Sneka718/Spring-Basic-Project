package com.example.service;
	import com.example.exception.LeaveNotFoundException;
	import com.example.model.Employee;
	import org.springframework.stereotype.Service;

	import java.util.ArrayList;
	import java.util.List;

	@Service
	public class EmployeeService {

	    private final List<Employee> leaves = new ArrayList<>();

	    public Employee applyLeave(Employee leave) {
	        leaves.add(leave);
	        return leave;
	    }

	    public List<Employee> getAllLeaves() {
	        return leaves;
	    }

	    public Employee getLeaveById(int id) {

	        for (Employee leave : leaves) {
	            if (leave.getEmployeeId() == id) {
	                return leave;
	            }
	        }

	        throw new LeaveNotFoundException(
	                "Leave not found with employee id: " + id);
	    }

	    public Employee updateLeave(
	            int id, Employee updatedLeave) {

	        Employee existingLeave = getLeaveById(id);

	        existingLeave.setEmployeeName(
	                updatedLeave.getEmployeeName());

	        existingLeave.setLeaveType(
	                updatedLeave.getLeaveType());

	        existingLeave.setNumberOfDays(
	                updatedLeave.getNumberOfDays());

	        existingLeave.setReason(
	                updatedLeave.getReason());

	        return existingLeave;
	    }
	    public String deleteLeave(int id) {

	        Employee leave = getLeaveById(id);

	        leaves.remove(leave);

	        return "Leave deleted successfully";
	    }
	}