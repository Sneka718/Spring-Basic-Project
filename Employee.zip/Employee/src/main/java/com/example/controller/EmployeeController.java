package com.example.controller;
	import com.example.model.Employee;
	import com.example.service.EmployeeService;
	import jakarta.validation.Valid;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;

	import java.util.List;

	@RestController
	@RequestMapping("/leaves")
	public class EmployeeController {

	    private final EmployeeService service;

	    public EmployeeController(EmployeeService service) {
	        this.service = service;
	    }

	    @PostMapping
	    public ResponseEntity<Employee> applyLeave(
	            @Valid @RequestBody Employee leave) {

	        return ResponseEntity.ok(
	                service.applyLeave(leave)
	        );
	    }

	    @GetMapping
	    public ResponseEntity<List<Employee>> getAllLeaves() {

	        return ResponseEntity.ok(
	                service.getAllLeaves()
	        );
	    }
	    
	    @GetMapping("/{id}")
	    public ResponseEntity<Employee> getLeaveById(
	            @PathVariable int id) {

	        return ResponseEntity.ok(
	                service.getLeaveById(id)
	        );
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Employee> updateLeave(
	            @PathVariable int id,
	            @Valid @RequestBody Employee leave) {

	        return ResponseEntity.ok(
	                service.updateLeave(id, leave)
	        );
	    }
	    
	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteLeave(
	            @PathVariable int id) {

	        return ResponseEntity.ok(
	                service.deleteLeave(id)
	        );
	    }
	}
