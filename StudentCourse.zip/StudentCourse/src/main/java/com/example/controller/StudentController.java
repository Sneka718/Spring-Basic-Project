package com.example.controller;
	import com.example.model.Student;
	import com.example.service.StudentService;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;
	import java.util.List;

	@RestController
	@RequestMapping("/students")
	public class StudentController {

	    private StudentService service;

	    public StudentController(StudentService service) {
	        this.service = service;
	    }

	    @PostMapping
	    public Student registerStudent(@RequestBody Student student) {

	        return service.registerStudent(student);
	    }

	    @GetMapping
	    public List<Student> getAllStudents() {

	        return service.getAllStudents();
	    }

	    @GetMapping("/{id}")
	    public Student getStudentById(@PathVariable int id) {

	        return service.getStudentById(id);
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteStudent(
	            @PathVariable int id) {

	        service.deleteStudent(id);

	        return ResponseEntity.ok(
	                "Student registration deleted successfully"
	        );
	    }
	}
