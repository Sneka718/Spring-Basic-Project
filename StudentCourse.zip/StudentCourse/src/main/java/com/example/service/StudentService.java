package com.example.service;
	import com.example.exception.StudentNotFoundException;
	import com.example.model.Student;
	import org.springframework.stereotype.Service;
	import java.util.ArrayList;
	import java.util.List;

	@Service
	public class StudentService {

	    private List<Student> students = new ArrayList<>();

	    public Student registerStudent(Student student) {

	        students.add(student);

	        return student;
	    }

	    public List<Student> getAllStudents() {

	        return students;
	    }

	    public Student getStudentById(int id) {

	        for (Student student : students) {

	            if (student.getStudentId() == id) {
	                return student;
	            }
	        }

	        throw new StudentNotFoundException(
	                "Student not found with id: " + id
	        );
	    }

	    public void deleteStudent(int id) {

	        Student student = getStudentById(id);

	        students.remove(student);
	    }
	}
