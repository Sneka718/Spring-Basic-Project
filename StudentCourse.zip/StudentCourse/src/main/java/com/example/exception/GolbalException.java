package com.example.exception;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.ExceptionHandler;
	import org.springframework.web.bind.annotation.RestControllerAdvice;

	@RestControllerAdvice
	public class GolbalException {

	    @ExceptionHandler(StudentNotFoundException.class)
	    public ResponseEntity<String> handleStudentNotFound(
	            StudentNotFoundException ex) {

	        return new ResponseEntity<>(
	                ex.getMessage(),
	                HttpStatus.NOT_FOUND
	        );
	    }
	}

